package com.springstudy.mythymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MythymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
